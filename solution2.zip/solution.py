import cv2
import numpy as np
from sklearn.model_selection import train_test_split

# Quiz 1
def aspect_resize(image, width=None, height=None, inter=cv2.INTER_AREA):
    dim = None
    (h, w) = image.shape[:2]

    if width is None and height is None:
        return image

    if width is None:
        r = height / float(h)
        dim = (int(w * r), height)
    else:
        r = width / float(w)
        dim = (width, int(h * r))

    resized = cv2.resize(image, dim, interpolation=inter)

    return resized


# Quiz 2
def aspect_preprocess(image, width, height):
    (h, w) = image.shape[:2]
    dW = 0
    dH = 0

    if w < h:
        image = aspect_resize(image, width=width)
        dH = int((image.shape[0] - height) / 2.0)

    else:
        image = aspect_resize(image, height=height)
        dW = int((image.shape[1] - width) / 2.0)

    (h, w) = image.shape[:2]
    image = image[dH:h - dH, dW:w - dW]

    return cv2.resize(image, (width, height))


# Quiz 3
def load_data(data):
    return data.astype("float") / 255.0


# Quiz 4
def encode_label(labels):
	temp = []
	for name in labels :
		if name not in temp :
			temp.append(name)
    return temp


# Quiz 5
def split_valid(data, labels):
    (trainX, testX, trainY, testY) = train_test_split(data, labels, test_size=0.20, 
                                                                        random_state=42)
    return train_test_split(trainX, trainY, test_size=0.15, 
                                                                        random_state=42)


# Quiz 6
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import BatchNormalization, Dropout
from tensorflow.keras.layers import Conv2D, MaxPool2D
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dense, Input

def miniVGG(x, classNames):
	# 아래의 주석이 CNN의 기본 뼈대가 됩니다.
	model = Sequential()
	# 인풋레이어, shape 주의
	# CONV(32개 필터), CONV(32개 필터), POOL
	model.add(Conv2D(32, (3,3), activation='relu', padding='same', input_shape=x.shape[1:]))
	model.add(BatchNormalization())
	model.add(Conv2D(32, (3,3), activation='relu', padding='same'))
	model.add(BatchNormalization())
	model.add(MaxPool2D())
	model.add(Dropout(0.4))
	# CONV(64개 필터), CONV(64개 필터), POOL
	model.add(Conv2D(64, (3,3), activation='relu', padding='same'))
	model.add(BatchNormalization())
	model.add(Conv2D(64, (3,3), activation='relu', padding='same'))
	model.add(BatchNormalization())
	model.add(MaxPool2D())
	model.add(Dropout(0.4))
	# Conv 레이어에서 Dense 레이어로 넘어가기 위한 레이어
	model.add(Flatten())
	# Fully Connected(512개 노드)
	model.add(Dense(512, activation='relu'))
	model.add(Dropout(0.5))
	# 아웃풋레이어, 클래스 개수 주의
	model.add(Dense(len(classNames), activation='softmax'))
	return model
