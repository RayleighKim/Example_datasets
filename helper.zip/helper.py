from imutils import paths
import numpy as np
import matplotlib.pyplot as plt
import cv2
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.layers import Input, Conv2D, BatchNormalization, Activation
from tensorflow.keras.layers import MaxPool2D, Add, GlobalAvgPool2D, Dense
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import EarlyStopping

def Q1helper(image):
    h, w = image.shape[:2]
    ds = de = abs(int( (h-w)/2 ))
    if abs( h-w ) % 2 == 1 :
        ds = ds + 1
    if h > w :
        image = image[ds:h-de,:]
    else : 
        image = image[:,ds:w-de]
    return image

def Q2helper(labels):
	return np.array([1 if label=='cat' else 0 for label in labels])

def Q3helper(data, labels):
	x_train, x_test, y_train, y_test = train_test_split(data, labels, test_size=0.15, random_state=2021)
	x_train, x_valid, y_train, y_valid = train_test_split(x_train, y_train, test_size=15/(70+15), random_state=2021)
	return x_train, y_train, x_valid, y_valid, x_test, y_test

def Q4helper(x_train, x_valid, x_test):
	mean_ = x_train.mean()
	std_ = x_train.std()
	x_train = (x_train - mean_)/std_
	x_valid = (x_valid - mean_)/std_
	x_test = (x_test - mean_)/std_
	return x_train, x_valid, x_test

def Q5helper():
	keras.backend.clear_session()
	il = Input(shape=(64,64,3))
	hl = Conv2D(64, (3,3), padding='same', activation='relu')(il)
	hl = Conv2D(64, (7,7), (2,2), padding='same')(hl)
	hl = BatchNormalization()(hl)
	hl = Activation('relu')(hl)
	hl = MaxPool2D((2,2))(hl)
	b1 = Conv2D(64, (3,3), padding='same')(hl)
	b1 = BatchNormalization()(b1)
	b1 = Activation('relu')(b1)
	b1 = Conv2D(64, (3,3), padding='same')(b1)
	b1 = BatchNormalization()(b1)
	hl = Add()([hl, b1])
	hl = Activation('relu')(hl)
	b2 = Conv2D(128, (3,3), padding='same')(hl)
	b2 = BatchNormalization()(b2)
	b2 = Activation('relu')(b2)
	b2 = Conv2D(128, (3,3), padding='same')(b2)
	b2 = BatchNormalization()(b2)
	b3 = Conv2D(128, (1,1))(hl)
	b3 = BatchNormalization()(b3)
	hl = Add()([b2, b3])
	hl = Activation('relu')(hl)
	hl = GlobalAvgPool2D()(hl)
	ol = Dense(1, activation='sigmoid')(hl)
	model = Model(il, ol)
	model.compile(loss = 'binary_crossentropy', optimizer = 'adam', metrics=['accuracy'])
	
	return model
	
def Q6helper(model, x_train, y_train, x_valid, y_valid):
	datagen = ImageDataGenerator(
			rotation_range=20,  # randomly rotate images in the range (degrees, 0 to 180)
			zoom_range = 0.2, # Randomly zoom image 
			width_shift_range=0.1,  # randomly shift images horizontally (fraction of total width)
			height_shift_range=0.1,  # randomly shift images vertically (fraction of total height)
			horizontal_flip=True,  # randomly flip images
			vertical_flip=True)  # randomly flip images

	datagen.fit(x_train)
	train_gen = datagen.flow(x_train, y_train, batch_size=64)

	es = EarlyStopping(monitor='val_loss', min_delta=0.0,
					   patience=5, verbose=1, restore_best_weights=True)

	model.fit(train_gen, epochs= 20,
			  validation_data=(x_valid, y_valid),
			  verbose=1, callbacks=[es] )
	return model