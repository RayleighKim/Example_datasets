def helper_q1(data1, data2):
    import pandas as pd
    temp = pd.concat([data1, data2], axis=0)
    temp = temp.drop(['id'], axis = 1)
    return temp

def helper_q2(data):
    from sklearn.model_selection import train_test_split

    x_train, x_test, y_train, y_test = train_test_split(data['document'], data['label'], 
                                                        test_size = 0.20, random_state=2021,
                                                        stratify = data['label'])
    x_train, x_valid, y_train, y_valid = train_test_split(x_train, y_train, 
                                                        test_size = 1/8, random_state=2021,
                                                        stratify = y_train)
    
    return x_train, x_valid, x_test, y_train, y_valid, y_test

def helper_q3(x_train, x_valid, x_test, y_train, y_valid, y_test) :
    return x_train.astype('str').tolist(), x_valid.astype('str').tolist(), x_test.astype('str').tolist(), y_train.tolist(), y_valid.tolist(), y_test.tolist()
	
def helper_q4(x_train, x_valid, x_test):
    from tensorflow.keras.preprocessing.text import Tokenizer

    tk = Tokenizer(num_words = 40000)
    tk.fit_on_texts(x_train)
    x_train = tk.texts_to_sequences(x_train)
    x_valid = tk.texts_to_sequences(x_valid)
    x_test = tk.texts_to_sequences(x_test)

    return x_train, x_valid, x_test
	
def assist_q5(x, y):
    x_, y_ = [], []
    for idx, seq in enumerate(x):
        if len(seq)>= 5 :
            x_.append( seq )
            y_.append( y[idx] )
    return x_, y_

def helper_q5(x_train, x_valid, x_test, y_train, y_valid, y_test):
    import numpy as np
    x_train, y_train = assist_q5(x_train, y_train)
    x_valid, y_valid = assist_q5(x_valid, y_valid)
    x_test, y_test = assist_q5(x_test, y_test)

    return x_train, x_valid, x_test, np.array(y_train), np.array(y_valid), np.array(y_test)

	
def helper_q6(x_train, x_valid, x_test):
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    max_len = 20
    x_train =  pad_sequences(x_train, maxlen=max_len)
    x_valid =  pad_sequences(x_valid, maxlen=max_len)
    x_test =  pad_sequences(x_test, maxlen=max_len)

    return x_train, x_valid, x_test
	
def helper_q7():
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras.layers import Embedding,Conv1D, MaxPool1D, Bidirectional, LSTM, GRU, Dense
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.backend import clear_session

    clear_session()

    model = Sequential()
    model.add(Embedding(40000, 256, input_length=20))
    model.add(Conv1D(256, 5, activation='swish'))
    model.add(Conv1D(256, 5, activation='swish'))
    fl = LSTM(192, return_sequences=True)
    bl = GRU(192, return_sequences=True, go_backwards=True)
    model.add(Bidirectional(fl, backward_layer=bl))
    fl2 = GRU(256, return_sequences=True)
    bl2 = LSTM(256, return_sequences=True, go_backwards=True)
    model.add(Bidirectional(fl2, backward_layer=bl2))
    model.add(LSTM(512))
    model.add(Dense(1, activation='sigmoid'))

    model.compile(loss = 'binary_crossentropy',
                optimizer='adam',
                metrics=['accuracy'])
    return model

def helper_q8(model, x_train, y_train, x_valid, y_valid)):
    from tensorflow.keras.callbacks import EarlyStopping

    es = EarlyStopping(monitor='val_loss',
                    min_delta=0,
                    patience=2,
                    verbose=1,
                    restore_best_weights=True)

    model.fit(x_train, y_train, validation_data=(x_valid, y_valid), epochs=10,
            verbose=True, batch_size=512, callbacks=[es])